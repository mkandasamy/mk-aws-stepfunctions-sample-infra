/*! Copyright Disney. All rights reserved. */
'use strict';

/****** AWS Swagger Documentation ******
  Import API Base Documentation:
  https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-import-api.html
  Extension Definitions:
  https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-swagger-extensions.html

******/

module.exports = {
    info: {
        description: 'Lambda Function Module Description.',
        contact: {
            name: 'Lambda Function Module Support'
        },
        version: process.env.npmPackageVersion
    },
    swagger: '2.0',
    definitions: {
        security: {
          'lambda-authorizer': []
        }

    },
    securityDefinitions: {
      'lambda-authorizer': {
         type: 'apiKey',
         name: 'Cookie',
         in: 'header',
         'x-amazon-apigateway-authtype': 'custom',
         'x-amazon-apigateway-authorizer': {
            authorizerUri: '$snow:LIGHT',
            authorizerResultTtlInSeconds: 300,
            identitySource: 'method.request.header.Cookie',
            type: 'request'
         }
      }
    }
};
